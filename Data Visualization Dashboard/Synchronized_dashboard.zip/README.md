In the top left area chart, the tooltip locks onto the topmost layer of the area chart when all charts are synchronized together.

Also, I did not make the appearance of tooltips exactly the same as the demo. I was told by one of the TA that the tooltip would be fine. 

Below are the major websites that my creation of dashboard rely upon:
https://www.highcharts.com/demo/synchronized-charts
https://www.highcharts.com/demo/area-basic
https://www.w3schools.com/html/html_tables.asp
https://api.highcharts.com/highcharts/
